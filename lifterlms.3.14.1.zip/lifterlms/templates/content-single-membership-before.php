<?php
/**
 * The Template for displaying all single membership.
 *
 * @author 		codeBOX
 * @package 	lifterLMS/Templates
 *
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
llms_print_notices();
do_action( 'lifterlms_single_membership_before_summary' );


