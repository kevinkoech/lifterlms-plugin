<?php
/**
 * The Template for displaying the quiz.
 *
 * @author 		codeBOX
 * @package 	lifterLMS/Templates
 *
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

do_action( 'lifterlms_single_quiz_after_summary' );
