<?php
/**
 * The Template for displaying quiz
 *
 * @author 		codeBOX
 * @package 	lifterLMS/Templates
 *
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
llms_print_notices();
do_action( 'lifterlms_single_question_before_summary' );


