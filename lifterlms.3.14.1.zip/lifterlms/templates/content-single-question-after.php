<?php
/**
 * The Template for displaying the quiz.
 *
 * @author 		codeBOX
 * @package 	lifterLMS/Templates
 *
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
do_action( 'lifterlms_single_question_after_summary', $args );
