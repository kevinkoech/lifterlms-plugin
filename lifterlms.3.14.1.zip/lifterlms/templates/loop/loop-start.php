<?php
/**
 * LifterLMS Loop Start Wrapper
 *
 * @since   1.0.0
 * @version 3.0.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; } // End if().
?>
<div class="llms-loop">
	<ul class="llms-loop-list<?php echo llms_get_loop_list_classes(); ?>">
