<?php
/**
 * Single Quiz: Next Question closing wrapper
 * @since    1.0.0
 * @version  1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
</div><!--end llms-quiz-wrapper-->
