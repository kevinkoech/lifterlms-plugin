<?php
/**
 * Quiz Wrapper: Open
 * @since    1.0.0
 * @version  3.9.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div class="llms-quiz-wrapper" id="llms-quiz-wrapper">
