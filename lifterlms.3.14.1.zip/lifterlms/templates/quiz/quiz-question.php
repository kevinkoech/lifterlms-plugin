<?php
/**
 * Single Quiz: Question Opening Wrapper
 * @since    1.0.0
 * @version  3.9.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

?>
<div class="llms-quiz-question-wrapper" id="llms-quiz-question-wrapper"></div>
