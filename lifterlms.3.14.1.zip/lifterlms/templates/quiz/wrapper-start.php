<?php
/**
 * Single Quiz: Wrapper Start
 * @version  3.9.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
global $question;
?>
<form method="POST" action="" name="llms_answer_question" enctype="multipart/form-data">
