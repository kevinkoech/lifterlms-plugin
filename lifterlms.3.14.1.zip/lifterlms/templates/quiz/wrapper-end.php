<?php
/**
 * Single Quiz: Wrapper end
 * @since    1.0.0
 * @version  3.9.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

?>
</form>
