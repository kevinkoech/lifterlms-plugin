<?php
/**
 * LifterLMS Course Meta Information Wrapper End
 * @author 		LifterLMS
 * @package 	LifterLMS/Templates
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
?>

</div><!-- .llms-meta-info -->
